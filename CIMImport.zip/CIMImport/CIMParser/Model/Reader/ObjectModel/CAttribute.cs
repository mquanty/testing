﻿namespace CIM.Model
{
    class CAttribute
    {
        public string name;
        public string type;
    }
}
