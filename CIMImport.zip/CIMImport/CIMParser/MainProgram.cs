﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using CIM.Model;
using CIMParser;
//using FTN.Common;
//using FTN.ESI.SIMES.CIM.CIMAdapter;
//using FTN.ESI.SIMES.CIM.CIMAdapter.Manager;

namespace CimXmlImport
{
    internal class Program
    {
        //private static CIMAdapter adapter = new CIMAdapter();
        //private static Delta nmsDelta = null;
        //private static string filePath = @"C:\Users\MANOJ\Desktop\CIM\SRLDC_CIM_V1.xml";
        private static string filePath = @"C:\Users\MANOJ\Desktop\CIM\cimrldc\NRLDC\1.xml";
        //private static SupportedProfiles selectedProfile = SupportedProfiles.EMS;

        static void Main(string[] args)
        {
            Test();
        }
        static void Test()
        {
            string log;

            using (FileStream fs = File.Open(filePath, FileMode.Open))
            {
                log = string.Empty;
                System.Globalization.CultureInfo culture = Thread.CurrentThread.CurrentCulture;
                Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
                try
                {
                    CIMModelLoaderResult modelLoadResult = CIMModelLoader.LoadCIMXMLModel(fs, filePath, out CIMModel cimModel); //ProfileManager.Namespace
                    if (modelLoadResult.Success) //load successfull
                    {
                        Console.WriteLine($"{filePath} load successful");
                        log = modelLoadResult.Report.ToString();
                    }
                }
                catch (Exception e)
                {
                    log = e.Message;
                }
                finally
                {
                    Thread.CurrentThread.CurrentCulture = culture;
                }
                File.WriteAllText("logfile.txt", log);
            }

            //CIMModelLoaderResult modelLoadResult2 = CIMModelLoader.LoadCIMXMLModel(null, filePath, out CIMModel cimModel2); //ProfileManager.Namespace
        }
        //static void ConvertCIMXMLToDMSNetworkModelDelta()
        //{
        //    ////SEND CIM/XML to ADAPTER
        //    try
        //    {
        //        //MessageBox.Show("Must enter CIM/XML file.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        string log;
        //        using (FileStream fs = File.Open(filePath, FileMode.Open))
        //        {
        //            nmsDelta = adapter.CreateDelta(fs, selectedProfile, out log); /*(SupportedProfiles)profileName*/
        //            //richTextBoxReport.Text = log;
        //            File.WriteAllText("logfile.txt", log);
        //        }
        //        if (nmsDelta != null)
        //        {
        //            //// export delta to file
        //            using (XmlTextWriter xmlWriter = new XmlTextWriter("deltaExport.xml", Encoding.UTF8))
        //            {
        //                xmlWriter.Formatting = Formatting.Indented;
        //                nmsDelta.ExportToXml(xmlWriter);
        //                xmlWriter.Flush();
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine($"An error occurred.\n\n{e.Message}");
        //    }
        //}

        //static void ApplyDMSNetworkModelDelta()
        //{
        //    //// APPLY Delta
        //    if (nmsDelta != null)
        //    {
        //        try
        //        {
        //            string log = adapter.ApplyUpdates(nmsDelta);
        //            //richTextBoxReport.AppendText(log);
        //            File.WriteAllText("logfile.txt", log);
        //            nmsDelta = null;
        //            //buttonApplyDelta.Enabled = (nmsDelta != null);
        //        }
        //        catch (Exception e)
        //        {
        //            Console.WriteLine($"An error occurred.\n\n{e.Message}");
        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine("No data is imported into delta object.");
        //    }
        //}

    }
}
